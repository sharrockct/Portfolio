﻿/* CS-330 Final Project
*  
*   author: code provided by SNHU and modified by Chris Sharrock
* 
*	7/15/23 - Module 3 milestone (modelling of the launch pad) completed
*   7/21/23 - Module 4 milestone (ground plane) completed
*/

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader.h"
#include "camera.h"

#include "pyramid.h"  // for easy creation of a pyramid in OpenGL

#include <iostream>

using namespace std;

// declare 
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow *window);
unsigned int loadTexture(const char *path);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// camera
Camera camera(glm::vec3(0.0f, 0.0f, 3.0f));
float lastX = SCR_WIDTH / 2.0f;
float lastY = SCR_HEIGHT / 2.0f;
bool firstMouse = true;

// timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

// lighting
glm::vec3 lightPos(1.2f, 1.0f, 2.0f);


// Creates a cylinder mesh centered on the origin 0, 0, 0)
class Cylinder {

protected:
	float radius;
	float height;
	int numSlices;
	int numVertices;
	int stride;

	float* vertices;
	unsigned int* triangles;

public:

	unsigned int VAO;
	unsigned int VBO[2];
	int indexSpace;

	Cylinder(float p_radius, float p_height, int p_slices, float p_red, float p_green, float p_blue) {
		
		// Set attributes to parameter values
		radius = p_radius;
		height = p_height;
		numSlices = p_slices;
		
		const int POS_ELEMENTS = 3;
		const int COLOR_ELEMENTS = 4;
		const int ELEMENTS_PER_VERTEX = 7;
		const int TRIANGLES_PER_SLICE = 4;
		
		float degreesPerSlice = 360 / numSlices;

		// Calculate total number of vertices
		numVertices = (numSlices + 1) * 2;

		vertices = new float[numVertices * ELEMENTS_PER_VERTEX];

		float currentAngle = 0.0;
		
		for (int i = 0; i < numVertices * ELEMENTS_PER_VERTEX; i+=7) {

			float nextX = 0.0f;
			float nextY = 0;
			float nextZ = 0;
			int j = 0; // index used for tracking position elements
			int k = 0; // index used for tracking color elements
			
			if (i == 0) {
				nextX = 0.0f;
				nextY = 0.0f + (height / 2);
				nextZ = 0.0f; 
			}
			else if (i == numVertices - 1) {
				nextX = 0.0f;
				nextY = 0.0f - (height / 2);
				nextZ = 0.0f;
			}
			else {
				nextX = radius * cos(currentAngle);
				nextZ = radius * sin(currentAngle);

				if (i <= numVertices / 2) {
					nextY = 0.0f + (height / 2);
				}
				else {
					nextY = 0.0f - (height / 2);
				}

				currentAngle += degreesPerSlice;
			}
			
			// load position values for next vertex into array
			for (j = 0; j < 3; j++) {

				if (j == 0) {
					vertices[i + j] = nextX;
				}
				else if (j == 1) {
					vertices[i + j] = nextY;
				}
				else {
					vertices[i + j] = nextZ;
				}
			}
			
			// load color values into array for this vertex
			for (k = 0; k < 4; k++) {

				if (k == 0) {
					vertices[i + j + k] = 1.0f;
				}
				else if (k == 1) {
					vertices[i + j + k] = 0.0f;
				}
				else if (k == 2) {
					vertices[i + j + k] = 0.0f;
				}
				else {
					vertices[i + j + k] = 1.0f;
				}
			}
		}

		// calculateTriangles();

		/*
		int dummyArray[72];
		indexSpace = sizeof(dummyArray) / sizeof(triangles[0]);
		stride = sizeof(float) * (ELEMENTS_PER_VERTEX + COLOR_ELEMENTS);

		glGenBuffers(2, VBO);
		glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, VBO[1]);

		// Use first VBO to upload position data (x, y, z) to GPU
		glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

		// Use second VBO to upload color data (r, g, b, opacity) to GPU
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(triangles), triangles, GL_STATIC_DRAW);

		// Specify location and format of position data for the GPU
		glVertexAttribPointer(0, POS_ELEMENTS, GL_FLOAT, GL_FALSE, stride, 0);
		glEnableVertexAttribArray(0);

		// Specify location and format of color data for the GPU
		glVertexAttribPointer(1, COLOR_ELEMENTS, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * POS_ELEMENTS));
		glEnableVertexAttribArray(1);
		*/
	}

	~Cylinder() {

		delete[] (vertices);
		delete[] (triangles);
	}

	void calculateTriangles() {

		int topTriangles = numSlices;
		int sideTriangles = numSlices * 2;
		int bottomTriangles = numSlices;
		int totalTriangles = topTriangles + sideTriangles + bottomTriangles;

		triangles = new unsigned int[totalTriangles];

		int loopIndex = 0;
		int a = 0;
		int b = 0;
		int c = 0;

		// Load top indices
		for (b = 0; b < topTriangles; b+=0) {

			b++;
			c = b + 1;

			if (c == topTriangles + 1) {
				c = 1;
			}

			triangles[loopIndex] = a;
			triangles[loopIndex + 1] = b;
			triangles[loopIndex + 2] = c;

			loopIndex += 3;
		}
		
		// Load side indices
		a = 1;
		b = a + numSlices;
		c = b + 1;

		for (int i = 0; i < sideTriangles/2; i++) {

			triangles[loopIndex] = a;
			triangles[loopIndex + 1] = b;
			triangles[loopIndex + 2] = c;

			loopIndex += 3;
			b = a;
			a++;

			if (c == sideTriangles + 1) {
				c = topTriangles + 1;
			}
			if (a == topTriangles + 1) {
				a = 1;
			}

			triangles[loopIndex] = a;
			triangles[loopIndex + 1] = b;
			triangles[loopIndex + 2] = c;

			loopIndex += 3;
			c++;
			b = c - 1;

			if (c == sideTriangles + 1) {
				c = topTriangles + 1;
			}
			if (a == topTriangles + 1) {
				a = 1;
			}
		}

		// Load bottom indices
		a = numVertices - 1;
		b = numSlices + 1;
		c = b + 1;

		for (int i = numSlices + 1; i < numVertices - 1; i++) {

			if (c == numVertices - 1) {
				c = numSlices + 1;
			}

			triangles[loopIndex] = a;
			triangles[loopIndex + 1] = b;
			triangles[loopIndex + 2] = c;

			loopIndex += 3;
			b++;
			c++;
		}
	}

	void render() {
		glBindVertexArray(VAO);

		// Render cylinder side first
		glDrawArrays(GL_TRIANGLE_STRIP, 0, (numSlices + 1) * 2);

		// Render top cover
		glDrawArrays(GL_TRIANGLE_FAN, ((numSlices + 1) * 2), (numSlices + 2));

		// Render bottom cover
		glDrawArrays(GL_TRIANGLE_FAN, ((numSlices + 1) * 2) + (numSlices + 2), (numSlices + 2));
	}
};





int main()
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Chris Sharrock", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);
	
	// build and compile our shader zprogram
	// ------------------------------------
	Shader sceneShader("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");




	Cylinder* test = new Cylinder(1, 1, 6, 1, 1, 1);





	// render loop
	// -----------
	while (!glfwWindowShouldClose(window))
	{
		// per-frame time logic
		// --------------------
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		// -----
		processInput(window);

		// render
		// ------
		glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// be sure to activate shader when setting uniforms/drawing objects
		sceneShader.use();
		// sceneShader.setVec3("viewPos", camera.Position);
		
		
		// view/projection transformations
		glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
		glm::mat4 view = camera.GetViewMatrix();
		sceneShader.setMat4("projection", projection);
		sceneShader.setMat4("view", view);

		// world transformation
		glm::mat4 model = glm::mat4(1.0f);
		sceneShader.setMat4("model", model);

		test->render();

		/*
		// Draw the scene
		glBindVertexArray(test->VAO);
		glDrawElements(GL_TRIANGLES, test->indexSpace, GL_UNSIGNED_INT, NULL);
		glBindVertexArray(0);
		*/

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// optional: de-allocate all resources once they've outlived their purpose:
	// ------------------------------------------------------------------------
	// glDeleteBuffers(1, &VBO);

	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow *window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		camera.ProcessKeyboard(FORWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		camera.ProcessKeyboard(BACKWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		camera.ProcessKeyboard(LEFT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		camera.ProcessKeyboard(RIGHT, deltaTime);
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

	lastX = xpos;
	lastY = ypos;

	camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	camera.ProcessMouseScroll(yoffset);
}

// utility function for loading a 2D texture from file
// ---------------------------------------------------
unsigned int loadTexture(char const * path)
{
	unsigned int textureID;
	glGenTextures(1, &textureID);

	int width, height, nrComponents;
	unsigned char *data = stbi_load(path, &width, &height, &nrComponents, 0);
	if (data)
	{
		GLenum format;
		if (nrComponents == 1)
			format = GL_RED;
		else if (nrComponents == 3)
			format = GL_RGB;
		else if (nrComponents == 4)
			format = GL_RGBA;

		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		stbi_image_free(data);
	}
	else
	{
		std::cout << "Texture failed to load at path: " << path << std::endl;
		stbi_image_free(data);
	}

	return textureID;
}