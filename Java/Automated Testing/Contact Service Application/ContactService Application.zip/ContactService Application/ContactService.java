/* Module 3 Milestone Assignment
 * ContactService class
 * 
 * Author: Chris Sharrock
 * Last modified: 6/10/23
 */

package contact_service;

import java.util.ArrayList; // Allows use of ArrayList

// This class manages a list of Contact objects and can add, find, update, 
// and remove contacts from the list.
public class ContactService {
	
	// ContactService attributes
	// Updated 6/10/23:
    //   - deleted nextId attribute and all references to it
	private ArrayList<Contact> contactList;
	
	// Constructor
	public ContactService() {
		this.contactList = new ArrayList<Contact>();
	}
	
	// ContactService methods
	// Check number of elements in contact list
	public int getContactListLength() {
		return this.contactList.size();
	}
	
	// Add a contact to the contacts list
	// Updated 6/10/23:
	//   - replaced old parameter list with a single parameter of type Contact
	//   - added check for duplicate contact ID
	public void addContact(Contact p_contact) {
		
		// Check list to see if a contact already exists with the same ID; throw exception if found
		if (findContact(p_contact.getContactId()) != null) {
			throw new IllegalArgumentException("Cannot have two contacts with the same ID.");
		}
		// Otherwise, add contact to the end of the contact list
		else {
			this.contactList.add(p_contact);
		}
	}
	
	// Locate and return a contact by ID
	public Contact findContact(String p_id) {
		
		// Check each contact's ID to find a match
		for (Contact c: contactList) {	
			// If found, return the matching contact
			if (c.getContactId().equals(p_id)) {
				return c;
			}
		}
		// If not found, return null
		return null;
	}
	
	// Locate a contact by ID and remove from the contacts list
	public void removeContact(String p_id) {		
		
		// Search for contact in contact list and remove from list
		contactList.remove(this.findContact(p_id));
	}
	
	// Find a contact by its ID and then update the specified info field with the new information
	public void updateFirstName(String p_id, String p_newValue) {	
		this.findContact(p_id).setFirstName(p_newValue);
	}	
	public void updateLastName(String p_id, String p_newValue) {
		this.findContact(p_id).setLastName(p_newValue);
	}
	public void updatePhoneNumber(String p_id, String p_newValue) {
		this.findContact(p_id).setPhoneNumber(p_newValue);
	}
	public void updateAddress(String p_id, String p_newValue) {		
		this.findContact(p_id).setAddress(p_newValue);
	}
}
