/* Module 3 Milestone Assignment
 * ContactServiceTest class
 * 
 * Author: Chris Sharrock
 * Last modified: 6/10/23
 */

package test;

//Import files needed to use the JUnit testing tool
import org.junit.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import contact_service.ContactService; // Class to be tested
import contact_service.Contact;

//This class tests the functionality of the "ContactService" class to ensure requirements are met
class ContactServiceTest {

	// Objects to be used for testing
	// Updated 6/10/23:
	//   - moved instantiation of "sut" to the beginning of each test
	//   - added test Contact objects to replace incorrect way of adding new contacts and updated in all test methods
	ContactService sut;
	Contact testContact1 = new Contact("Test1", "Chris", "Sharrock", "1234567890", "123 Streetly Ln, Anywhere, US");
	Contact testContact2 = new Contact("Test1", "Sam", "Thompson", "0987654321", "456 Lanely St, Anywhere, US");
	
	@Test
	// Test for successful creation of a "ContactService" object
	void testContactService() {
		sut = new ContactService();
		assertTrue(sut != null);
	}
	
	@Test
	// Test for successful addition of a new contact to the list
	void testContactService_AddContactToList() {
		sut = new ContactService();
		assertTrue(sut.getContactListLength() == 0); // Check list before adding
		sut.addContact(testContact1);
		assertTrue(sut.getContactListLength() == 1); // Check list after adding
	}
	
	// Updated 6/10/23:
	//   - added new test method: testContactService_CantHaveDuplicateIds
	@Test
	// Test for proper handling of duplicate contact IDs
	void testContactService_CantHaveDuplicateIds() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			sut = new ContactService();
			sut.addContact(testContact1);
			sut.addContact(testContact2);
		});
	}
 	
	@Test
	// Test function of updating contact's first name
	void testContactService_UpdateFirstName() {	
		sut = new ContactService();
		sut.addContact(testContact1);
		sut.updateFirstName("Test1", "Snake");
		assertTrue(sut.findContact("Test1").getFirstName().equals("Snake"));
	}
	
	@Test
	// Test function of updating contact's last name
	void testContactService_UpdateLastName() {	
		sut = new ContactService();
		sut.addContact(testContact1);
		sut.updateLastName("Test1", "Eyes");
		assertTrue(sut.findContact("Test1").getLastName().equals("Eyes"));
	}
	
	@Test
	// Test function of updating contact's phone number
	void testContactService_UpdatePhoneNumber() {	
		sut = new ContactService();
		sut.addContact(testContact1);
		sut.updatePhoneNumber("Test1", "0987654321");
		assertTrue(sut.findContact("Test1").getPhoneNumber().equals("0987654321"));
	}
	
	@Test
	// Test function of updating contact's address
	void testContactService_UpdateAddress() {
		sut = new ContactService();
		sut.addContact(testContact1);
		sut.updateAddress("Test1", "321 Livington Hwy");
		assertTrue(sut.findContact("Test1").getAddress().equals("321 Livington Hwy"));
	}
	
	@Test
	// Test for proper and complete removal of the contact from the list
	// Updated 6/10/23:
	//   - added line to add the Contact at beginning of test rather than before test
	void testContactService_RemoveContactFromList() {
		sut = new ContactService();
		sut.addContact(testContact1);
		assertTrue(sut.getContactListLength() == 1); // Check length before removal
		sut.removeContact("Test1");
		assertTrue(sut.getContactListLength() == 0); // Check length after removal
	}
}
