/* Module 3 Milestone Assignment
 * Contact class
 * 
 * Author: Chris Sharrock
 * Last modified: 6/10/23
 */

package contact_service;

// This class provides a structure for storing a contact's information
public class Contact {

	// Contact attributes
	private String contactId   = "";
	private String firstName   = "";
	private String lastName    = "";
	private String phoneNumber = "";
	private String address     = "";
	
	// Constructors
	// Updated 6/10/23: 
	//   - removed default constructor
	//   - contactId value now validated and set in constructor rather than in a separate method
	public Contact(String p_id, String p_firstName, String p_lastName, String p_phoneNumber, String p_address) {
		
		final int MAX_ID_LENGTH = 10; // Specify the length limit
		
		// Contact ID 
		// If the parameter value is null, throw exception
		if (p_id ==  null) {
			throw new IllegalArgumentException("Contact ID cannot be null.");
		}
		// If the parameter value exceeds the length limit, throw exception
		else if (p_id.length() > MAX_ID_LENGTH) {
			throw new IllegalArgumentException("Contact ID is limited to 10 characters or less.");
		}
		// Otherwise, set contact ID to parameter value
		else {
			this.contactId = p_id;
		}
		
		// Use set...() methods to set remaining attributes
		this.setFirstName(p_firstName);
		this.setLastName(p_lastName);
		this.setPhoneNumber(p_phoneNumber);
		this.setAddress(p_address);
	}
	
	// Getters
	public String getContactId() {
		return this.contactId;
	}
	public String getFirstName() {
		return this.firstName;
	}
	public String getLastName() {
		return this.lastName;
	}
	public String getPhoneNumber() {
		return this.phoneNumber;
	}
	public String getAddress() {
		return this.address;
	}
	
	// Setters
	// Updated 6/10/23: 
	//   - deleted setContactId() method; contactId can't be updated once set
	
	// Set the first name to the parameter value
	public void setFirstName(String p_name) {
		
		final int MAX_LENGTH = 10; // Specify the length limit

		// If the parameter value is null, throw exception
		if (p_name ==  null) {
			throw new IllegalArgumentException("First name cannot be null.");
		}
		// If the parameter value exceeds the length limit, throw exception
		else if (p_name.length() > MAX_LENGTH) {
			throw new IllegalArgumentException("First name is limited to 10 characters or less.");
		}
		// If no issues found, update contact ID
		else {
			this.firstName = p_name;
		}
	}
	// Set the last name to the parameter value
	public void setLastName(String p_name) {
		
		final int MAX_LENGTH = 10; // Specify the length limit

		// If the parameter value is null, throw exception
		if (p_name ==  null) {
			throw new IllegalArgumentException("Last name cannot be null.");
		}
		// If the parameter value exceeds the length limit, throw exception
		else if (p_name.length() > MAX_LENGTH) {
			throw new IllegalArgumentException("Last name is limited to 10 characters or less.");
		}
		// If no issues found, update contact ID
		else {
			this.lastName = p_name;
		}
	}
	// Set the phone number to the parameter value
	// Updated 6/10/23:
	//   - check added to ensure phone number only consists of digits
	public void setPhoneNumber(String p_number) {
		
		final int REQUIRED_LENGTH = 10; // Specify the length limit
	
		// If the parameter value is null, throw exception
		if (p_number ==  null) {
			throw new IllegalArgumentException("Phone number cannot be null.");
		}
		// If the parameter value is of invalid length, throw exception
		else if (p_number.length() != REQUIRED_LENGTH) {
			throw new IllegalArgumentException("Phone number must be 10 digits long.");
		}
		// If the parameter contains characters other than digits, throw exception
		else if (!p_number.matches("\\d{10}")) {
			throw new IllegalArgumentException("Phone number can only contain digits.");
		}
		// If no issues found, update contact ID
		else {
			this.phoneNumber = p_number;
		}
	}
	// Set the address to the parameter value
	public void setAddress(String p_address) {
		
		final int MAX_LENGTH = 30; // Specify the length limit

		// If the parameter value is null, throw exception
		if (p_address ==  null) {
			throw new IllegalArgumentException("Address cannot be null.");
		}
		// If the parameter value exceeds the length limit, throw exception
		else if (p_address.length() > MAX_LENGTH) {
			throw new IllegalArgumentException("Address is limited to 30 characters or less.");
		}
		// If no issues found, update contact ID
		else {
			this.address = p_address;
		}
	}
}
