/* Module 3 Milestone Assignment
 * ContactTest class
 * 
 * Author: Chris Sharrock
 * Last modified: 6/10/23
 */

package test;

// Import files needed to use the JUnit testing tool
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contact_service.Contact; // Class to be tested

// This class tests the functionality of the "Contact" class to ensure requirements are met
class ContactTest {

	@Test
	// Test for successful creation of a valid "Contact" object
	void testContact() {
		Contact sut = new Contact("0000000001", "Chris", "Sharrock", "1234567890", "123 Streetly Ln, Anywhere, US");
		assertTrue(sut.getContactId().equals("0000000001"));
		assertTrue(sut.getFirstName().equals("Chris"));
		assertTrue(sut.getLastName().equals("Sharrock"));
		assertTrue(sut.getPhoneNumber().equals("1234567890"));
		assertTrue(sut.getAddress().equals("123 Streetly Ln, Anywhere, US"));
	}
	
	@Test
	// Test for proper handling of a null contact ID
	void testContact_ContactIdCantBeNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Chris", "Sharrock", "1234567890", "123 Streetly Ln, Anywhere, US");
		});
	}
	
	@Test
	// Test for proper handling of a contact ID that exceeds the length limit (10 characters)
	void testContact_ContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("00000000001", "Chris", "Sharrock", "1234567890", "123 Streetly Ln, Anywhere, US");
		});
	}
	
	// Updated 6/10/23:
	//   - deleted textContact_ContactIdCantBeUpgraded; ability to change ID removed from Contact class
	
	@Test
	// Test for proper handling of a null first name
	void testContact_FirstNameCantBeNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", null, "Sharrock", "1234567890", "123 Streetly Ln, Anywhere, US");
		});
	}
	
	@Test
	// Test for proper handling of a first name that exceeds the length limit (10 characters)
	void testContact_FirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Christopher", "Sharrock", "1234567890", "123 Streetly Ln, Anywhere, US");
		});
	}

	@Test
	// Test for proper handling of a null last name
	void testContact_LastNameCantBeNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Chris", null, "1234567890", "123 Streetly Ln, Anywhere, US");
		});
	}
	
	@Test
	// Test for proper handling of a last name that exceeds the length limit (10 characters)
	void testContact_LasttNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Chris", "Bramer-Sharrock", "1234567890", "123 Streetly Ln, Anywhere, US");
		});
	}
	
	@Test
	// Test for proper handling of a null phone number
	void testContact_PhoneNumberCantBeNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Chris", "Sharrock", null, "123 Streetly Ln, Anywhere, US");
		});
	}
	
	@Test
	// Test for proper handling of a phone number that is shorter than the required length of 10 digits
	void testContact_PhoneNumberTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Chris", "Sharrock", "4567890", "123 Streetly Ln, Anywhere, US");
		});
	}
	
	@Test
	// Test for proper handling of a phone number that exceeds the required length of 10 digits
	void testContact_PhoneNumberTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Chris", "Sharrock", "0011234567890", "123 Streetly Ln, Anywhere, US");
		});
	}
	
	// Updated 6/10/23:
	//   - added new test method: testContact_PhoneNumberMustBeAllDigits()
	@Test
	// Test for proper handling of a phone number containing characters other than digits
	void testContact_PhoneNumberMustBeAllDigits() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Chris", "Sharrock", "I2E456789O", "123 Streetly Ln, Anywhere, US");
		});
	}
	
	@Test
	// Test for proper handling of a null address
	void testContact_AddressCantBeNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Chris", "Sharrock", "1234567890", null);
		});
	}
	
	@Test
	// Test for proper handling of an address that exceeds the length limit (30 characters)
	void testContact_AddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Chris", "Sharrock", "1234567890", "Next to the house of my best friend, Brandon, Anywhere, US");
		});
	}

}
