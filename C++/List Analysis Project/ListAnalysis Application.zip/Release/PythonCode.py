# CS-210 Project 3
#
# Written by:    Chris Sharrock
# Last modified: 02/19/2022
#
# This program takes an input file of purchases made througout the day and allows the user to see data from it in three ways: 
# 1.) A textual summary of the number of each item sold
# 2.) The number sold for an item specified by the user
# 3.) A graphical display of the number of each item sold (via histogram)
# The program is comprised of parts written with C++ and Python

import re
import string


# This function opens a file containing a list of items sold throughout the day and stores them as keys in a dictionary, with the values being the number of times each item was sold
def ReadFromFile(fileName):
    
    # Declare the dictionary for storing the sold items and a file reader
    itemsSold = {}
    f = open(fileName)  # Tells the reader to open the parameter filename
    
    # Reads the entire contents of the file as a single string, then splits the string into individual words, all stored within fileContents
    fileContents = f.read().split()

    # For each word in the list fileContents...
    for word in fileContents:

        # Update/create the item in the itemsSold dictionary and increase the value (number of times that item has been sold) by 1 
        itemsSold[word] = itemsSold.get(word, 0) + 1
    
    # Close the input file
    f.close()
    
    # Return the itemsSold dictionary populated with items (keys) and the number of times each was sold (values)
    return itemsSold


# This function outputs a list of all items sold during the day to screen with the number sold next to each item
def PrintTextSummary():

    # Populate a dictionary itemsSold using an input file
    itemsSold = ReadFromFile('CS210_Project_Three_Input_File.txt')

    # Display list header to screen
    print("Number of items sold by type:")
    print("-------------------------------")

    # Display the name of each item followed by the number of times each was sold next to it as a number
    for item, quantity in itemsSold.items():
        print('{} {}'.format(item, quantity))


# This function returns the number of times a specific item was sold during a day (based on an input file)
def FrequencyByItem(itemName):
    
    # Populate a dictionary itemsSold using an input file
    itemsSold = ReadFromFile('CS210_Project_Three_Input_File.txt')

    # Format the item name (passed as a parameter from user input on the C++ side) to match the format of the dictionary keys
    itemName = itemName.lower().capitalize()

    # Look for the item name in the itemsSold list and return number of times the item is listed (or 0 if the item was not found in the list)
    return itemsSold.get(itemName, 0)


# This function takes an input file containing a list of items sold, and writes to a new file containing the names of all items and the number of each sold
def WriteGraphicSummary():

    # Populate a dictionary itemsSold using an input file
    itemsSold = ReadFromFile('CS210_Project_Three_Input_File.txt')

    # Specify the name of the output file to be created (allows for easier modification later if needed)
    outputFile = "frequency.dat"    

    # Create a file reader and open/create the output file in writing mode
    f = open(outputFile, 'w')

    # For each item and quantity in the itemsSold dictionary, write a new line to the file listing the item name and quantity sold
    for item, quantity in itemsSold.items():
        outputText = str(item + ' ' + str(quantity) + '\n');
        f.write(str(outputText))

    # Close the output file
    f.close()

