// CS-210 Project 3
//
// Written by:    Chris Sharrock
// Last modified: 02/19/2022
//
// This program takes an input file of purchases made througout the day and allows the user to see data from it in three ways: 
// 1.) A textual summary of the number of each item sold
// 2.) The number sold for an item specified by the user
// 3.) A graphical display of the number of each item sold (via histogram)
// The program is comprised of parts written with C++ and Python

#include <Python.h>  // Enables interfacing with code written in Python
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>
#include <fstream>   // Enables use of file streams

using namespace std;


// DEFINITIONS OF FUNCTIONS THAT ALLOW INTERFACING WITH PYTHON
/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("PythonCode");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python function you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python function you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}


// C++ FUNCTION DECLARATONS (DEFINED BELOW MAIN)
// Prints the Corner Grocer logo and program title to the screen
void printTitleScreen();

// Displays the user menu, retrieves user input, and executes user's commands
void menuLoop();

// Prints a histogram given a list of item names and numbers from an input file
int createHistographFromFile(string fileName);


// MAIN()
int main() {

	// Print company logo and program title to screen
	printTitleScreen();

	// Retrieve user input and execute commands until user selects to exit program
	menuLoop();

	// Terminate normally
	return 0;
}


// C++ FUNCTION DEFINITIONS
// This function prints the Corner Grocer logo and program title to the screen
void printTitleScreen() {

	// Print Corner Grocer logo to screen
	cout << "          _ _         _ " << endl;
	cout << "         (*Y*)  _   /- /" << endl;
	cout << "        (* * *)[_] /- / " << endl;
	cout << "         (*\\\\\\/-  \\- /  _^" << endl;
	cout << "         /^^^^^^^^^^^^|///    " << endl;
	cout << "        /|   CORNER   |=<     " << endl;
	cout << "       / |            |\\\\\\ " << endl;
	cout << "       [ \\   GROCER   |  V" << endl;
	cout << "       \\   \\ __       |" << endl;
	cout << "        |\\_    \\>     |" << endl;
	cout << "        \\___\\ _/______/" << endl << endl;

	// Print program title to screen
	cout << " Product Sales Analaysis Program" << endl;
	cout << endl << endl;
}

// This function displays the user menu, retrieves user input, and executes user's commands
void menuLoop() {

	// Variables for storing user's inputs
	char   userSelection  = ' ';
	string itemToLookUp   = "";

	// Set exception mask for cin stream
	cin.exceptions(ios::failbit);

	// Loop until user selects to exit program (option 4)
	while (userSelection != '4') {

		// Display user menu to the screen
		cout << "***********************************************" << endl;
		cout << "* USER MENU:                                  *" << endl;
		cout << "*---------------------------------------------*" << endl;
		cout << "* 1 - Display text summary of items sold      *" << endl;
		cout << "* 2 - Look up number sold for a specific item *" << endl;
		cout << "* 3 - Display graphic summary of items sold   *" << endl;
		cout << "* 4 - Exit program                            *" << endl;
		cout << "*                                             *" << endl;
		cout << "***********************************************" << endl << endl;

		try {

			// Prompt user for input and retrieve their selection
			cout << "Enter selection (by number): ";
			cin >> userSelection;
			cout << endl;

			// Branch to execute user's command
			switch (userSelection) {

				case '1': // Execute option to display a text summary of all items sold

					// Call Python function to print text summary
					CallProcedure("PrintTextSummary");
					cout << endl;
					break;

				case '2': // Execute option to look up the number of times a specific item was sold

					// Clears the input stream of any remaining characters
					cin.ignore(100, '\n');

					// Get item to look up from user input
					cout << "Item to look up: ";
					cin >> itemToLookUp;
					cout << endl;

					// Call Python function "FrequencyByItem" to get number of times the item was sold and output to screen
					cout << "Number of \"" << itemToLookUp << "\" items sold today: " << callIntFunc("FrequencyByItem", itemToLookUp);
					cout << endl << endl << endl;
					break;

				case '3': // Execute option to display a histogram showing all items sold

					// Call Python function "WriteGrapicSummary" to write a .dat file with items and the number of times each was sold
					CallProcedure("WriteGraphicSummary");

					// Read the .dat file generated above and generate a histogram from the data
					createHistographFromFile("frequency.dat");
					cout << endl;
					break;

				case '4': // Execute command to terminate program (breaks while loop and allows function to end)

					// Inform user program is terminating
					cout << "Terminating program..." << endl << endl;
					break;

				default: // All other values are invalid selections; inform user via error message
					cout << "Invalid selection. Please choose from the following menu:" << endl << endl;
					break;
			}
		}
		// Catches exceptions due to input incompatible with storing variables
		catch (const ios_base::failure& excpt) {

			// Output error message to screen
			cout << "Invalid input error. Returning to main menu." << endl;

			// Reset the status flags
			cin.clear();
		}

		// Clears the input stream of any remaining characters
		cin.ignore(100, '\n');
	}
}

// This function reads a .dat file (generated by the WriteGraphicSummary() Python function) and prints a histogram to the 
// *** Note: function declared as type "int" to allow returning if there is an issue with opening the file ***
int createHistographFromFile(string fileName) {  

	ifstream inFS;     // Used to read input from the file
	string   itemName; // Used to store item names from the input file
	int      numSold;  // Used to store the number of each item sold from the input file

	// Attempt to open the input file
	inFS.open(fileName);

	// If file can't be opened, print an error message and return to main menu
	if (!inFS.is_open()) {
		cout << "Could not open file \"" << fileName << "\". Returning to menu." << endl;

		// End function due to error
		return 1;
	}

	// Display output header to the screen
	cout << "Items sold by type: " << endl;
	cout << "-------------------------------" << endl;

	// Loop until the ifstream has a failure (ideally due to hitting the end of file)
	while (!inFS.fail()) {

		// Get the next item name and number sold from the input file
		inFS >> itemName;
		inFS >> numSold;

		// If no failure happened after attempting to read from file, print next line to screen
		if (!inFS.fail()) {

			// Output the item name to screen followed by a space
			cout << itemName << " ";

			// Print an asterisk next to the item name for every item of that type sold
			for (int i = 1; i <= numSold; ++i) {
				cout << "*";
			}
			cout << endl;
		}
	}
	// After the ifstream has a failure, check to see if end of file was reached; if not, an input error occured
	if (!inFS.eof()) {

		// Inform user that the input failed before reaching the end of the file 
		cout << "Input failure before reaching end of file." << endl;
	}

	// Close input file
	inFS.close();
}