﻿/* CourseCatalogue.cpp
*  Version 1.0
* 
*  Author: Chris Sharrock
* 
*  Last Updated: 2/15/2023
*/

#include <iostream>
#include <ios>       // for streamsize
#include <limits>    // for numerical_limits
#include <vector>    // for use of vectors
#include <fstream>   // for use of fstream
#include <string>    // for use of 'getline()' function

using namespace std;

// Define "Course" struture for storing course information
struct Course {

	// Attributes
	string courseId;
	string courseTitle;
	vector<string> prerequisites;

	// Public Functions
	public:
		// Constructors
		Course() {} 
		Course(string courseId, string courseTitle, vector<string> prerequisites) {
			this->courseId = courseId;
			this->courseTitle = courseTitle;
			this->prerequisites = prerequisites;
		}
		// Destructor
		~Course() {
			prerequisites.clear(); // Free memory
		}
		// Prints course information (ID number and title)
		void PrintCourse() {
			cout << courseId << ", " << courseTitle << endl;
		}
		// Prints course's prerequisites on a single line
		void PrintPrerequsites() {
			cout << "Prerequisites: ";
			if (this->prerequisites.size() == 0) { // If list is empty, print "None"
				cout << "None" << endl;
			}
			else {	// Else, print all prerequisites on a line separated by commas
				for (int i = 0; i < prerequisites.size(); i++) { 
					cout << prerequisites.at(i);
					if (i != prerequisites.size() - 1) {
						cout << ", ";
					}
					else {
						cout << endl;
					}
				}
			}
		}
};

// Define class for a Binary Search Tree (BST) for storing courses
class BinarySearchTree {

	// Structure for the nodes which make up the BST
	struct Node {

		Course* course = nullptr;
		Node* left = nullptr;
		Node* right = nullptr;

		Node() {}
		Node(Course* course) {
			this->course = course;
		}
	};

	// Pointer to the tree's root node
	Node* root = nullptr;

	// Housekeeping Functions
	void addNode(Node* baseNode, Node* newNode);
	void removeNode(Node* node);
	void inOrder(Node* node);

	// Public Functions
	public:
		BinarySearchTree();  // Constructor
		~BinarySearchTree(); // Destructor
		void Insert(Course* course);     // Insert a node into the tree
		void PrintCourseList();          // Print all courses stored in the tree
		Course* Search(string courseId); // Find a specific course in the tree
};

// Counstructor
BinarySearchTree::BinarySearchTree() {
	Course* course = nullptr; 
	Node* left = nullptr;
	Node* right = nullptr;
}

// Destructor
BinarySearchTree::~BinarySearchTree() {

	// FIXME: Destructor
}


// Binary Search Tree Functions //
// Insert a new course into the BST
void BinarySearchTree::Insert(Course* course) {

	// Create a node to store the new course
	Node* newNode = new Node(course);

	// If the tree is empty, make the new node the root
	if (this->root == nullptr) {
		this->root = newNode;
	}
	// Else, call addNode to find the correct location
	else {
		this->addNode(this->root, newNode);
	}
}

// Print information of all courses stored in the tree
void BinarySearchTree::PrintCourseList() {

	// Call inOrder funtion to print all nodes in order
	this->inOrder(this->root);
}

// Find a specific course in the BST
Course* BinarySearchTree::Search(string courseId) {

	// Start with the root node
	Node* currentNode = this->root;

	// Traverse through the tree to find the specified course
	while (currentNode != nullptr) {
		// If match found, return current node
		if (courseId == currentNode->course->courseId) {
			return currentNode->course;
		}
		// Else, traverse to appropriate subtree
		else if (courseId < currentNode->course->courseId) {
			currentNode = currentNode->left;
		}
		else {
			currentNode = currentNode->right;
		}
	}
	// If course not found, return null;
	Course* course = nullptr;
	return course;
}

// HOUSEKEEPING FUNCTIONS //
// Called recursively to find the correct place for a new node
void BinarySearchTree::addNode(Node* baseNode, Node* newNode) {
	
	// If new course's ID is less than course ID in the baseNode
	if (newNode->course->courseId < baseNode->course->courseId) {
		// If left node doesn't exist, make new node left node
		if (baseNode->left == nullptr) {
			baseNode->left = newNode;
		}
		// Else, traverse left
		else {
			this->addNode(baseNode->left, newNode);			
		}
	}
	// Else, course ID is greater than course ID in baseNode
	else {
		// If right node doesn't exist, make new node left node
		if (baseNode->right == nullptr) {
			baseNode->right = newNode;
		}
		// Else, traverse right
		else {
			this->addNode(baseNode->right, newNode);
		}
	}
}

// Called recursively to visit nodes in ascending order
void BinarySearchTree::inOrder(Node* node) {
	
	// When an empty node is found, return
	if (node == nullptr) {
		return;
	}
	this->inOrder(node->left);   // Print courses stored in left subtree
	node->course->PrintCourse(); // Print course in current node
	this->inOrder(node->right);  // Print courses stored in right subtree
}

// Called recursively to delete all nodes from the tree
void BinarySearchTree::removeNode(Node* node) {
	
	// When an empty node is found, return
	if (node == nullptr) {
		return;
	}
	this->removeNode(node->left);  // Clear nodes from left tree
	this->removeNode(node->right); // Clear nodes from right tree
	node = nullptr;                // Clear memory of current Node
}


// SORTING FUNCTIONS //
// Partitions a vector into upper and lower partitions
// Note: courses are sorted according to the digits of 
//       the course ID (the course level)
int partition(vector<vector<string>> &courses, int begin, int end) {

	// Sorting indices
	int lowIndex = begin;
	int highIndex = end;
	int pivot = lowIndex + ((highIndex - lowIndex) / 2);
	
	// Isolate the course level of the course at the pivot
	string pivotValue = courses[pivot][0].substr(4, 3);

	// Terminates while loop when complete
	bool done = false;

	// Loop through this list until low index and high index meet or pass each other
	while (!done) {

		// Tracks current index for comparison to pivot
		string indexValue;
		
		// Start with first value
		indexValue = courses[lowIndex][0].substr(4, 3);;
		// Search until a value greater than the pivot value is found
		while (indexValue < pivotValue) {
			lowIndex++; 
			indexValue = courses[lowIndex][0].substr(4, 3);;
		}

		// Start with the last value
		indexValue = courses[highIndex][0].substr(4, 3);;
		// Search until a value less than the pivot value is found
		while (indexValue > pivotValue) {
			highIndex--; 
			indexValue = courses[highIndex][0].substr(4, 3);;
		}

		// Sorting is completer when low and high indices meet or pass each other
		if (lowIndex >= highIndex) {
			done = true; // Trigger end of while loop
		}
		// Otherwise swap values at low and high index and iterate again
		else {
			std::swap(courses[lowIndex], courses[highIndex]);
			lowIndex++;
			highIndex--;
		}
	}

	// Return the final value of the high index (used as midpoint for quickSort())
	return highIndex;
}

// Called recursively to sort a vector by sections
void quickSort(vector<vector<string>> &courses, int begin, int end) {

	// Used to define lower and higher partitions
	int midpoint = 0;
	
	// If vector is empty, or has 1 element, sorting is unnecessary
	if (courses.size() <= 1 || begin >= end) {
		return;
	}

	// Call partition to sort into low and high partitions and get midpoint
	midpoint = partition(courses, begin, end);

	// Sort lower partition
	quickSort(courses, 0, midpoint);
	// Sort higher partition
	quickSort(courses, midpoint + 1, end);
}


// OTHER FUNCTIONS //
// Reads a list of course information from file and stores each course in a BST
void loadCourses(string filename, BinarySearchTree &courseList) {

	fstream fileReader;    // File input stream
	string nextLine;       // Stores each line read from file
	int loadSuccesses = 0; // Tracks courses loaded successfully
	int loadFailures = 0;  // Tracks courses which failed to load

	// Stores courses that have unfound prerequisites to check again
	// Note: prevents loading issues when a course is read from file 
	//		 before one or more of its prerequisites
	vector<vector<string>> checkAgain(0); 

	// Attempt to open file
	fileReader.open(filename);

	// If unable to open file, alert user and return to menu
	if (!fileReader.is_open()) {
		cout << "Unable to open file \"" << filename << "\"" << endl;
		return;
	}

	// Read first line from file
	getline(fileReader, nextLine);

	// Check first line for byte order mark; if found remove it from line
	if ((unsigned char)nextLine[0] == 0xEF && (unsigned char)nextLine[1] == 0xBB && (unsigned char)nextLine[2] == 0xBF) {
		nextLine = nextLine.substr(3, nextLine.length() - 3);
	}

	// Loop until end of file is reached
	while (!fileReader.fail()) {
	
		// Used for dividing a line into parts and storing course information
		vector<string> splitLine;
		string courseId;
		string courseTitle;
		vector<string> prerequisites(0);

		// Used for indexing to find the commas in a line
		int i = 0;
		int j = 0;

		// Split the current line into parts and store in "splitLine"
		for (i = 0; i < nextLine.length(); i++) {
			if (nextLine[i] == ',') {
				splitLine.push_back(nextLine.substr(j, i - j));
				j = i + 1;
			}
			else if (i == nextLine.length() - 1) {
				splitLine.push_back(nextLine.substr(j, i - 1));
			}
		}

		// Get next line from file to prepare for next iteration
		getline(fileReader, nextLine);

		// If there are less than two pieces of information, course failed to load
		if (splitLine.size() < 2) { 
			cout << "Course " << splitLine.at(1) << " failed to load due to missing course information." << endl; 
			loadFailures++;
			continue;
		}
		// If there are more than two pieces of information, course has prerequisites
		else if (splitLine.size() > 2) { 
			
			// Tracks whether course's prerequisites are valid
			bool validPrereqs = true;

			// Check BST to see if each prerequisite is in the tree
			for (i = 2; i < splitLine.size(); i++) {
				// If not, prerequisites may not be valid; add course to checkAgain list
				if (courseList.Search(splitLine.at(i)) == nullptr) {
					checkAgain.push_back(splitLine);
					validPrereqs = false;
					break;
				}
				// If found in tree, add prerequisite to "prerequisites" vector
				prerequisites.push_back(splitLine.at(i));
			}
			// If prerequisites could not be confirmed, skip to next iteration without creating a Course object
			if (validPrereqs == false) {
				continue;
			}
		}

		// If course information is valid, identify ID and course name
		courseId = splitLine.at(0);
		courseTitle = splitLine.at(1);
		
		// Create a Course object to store the course and add to the tree
		Course* course = new Course(courseId, courseTitle, prerequisites);
		courseList.Insert(course);
		loadSuccesses++;
	}
	// All lines have been read, close file
	fileReader.close(); 

	// Sort list of courses to check again according to course level
	// Note: A course should not have a prerequisite course with a 
	//       course level greater than its own. Sorting by level
	//       ensures that a course will still be loaded even if a 
	//       prerequisite is listed after it in the input file.
	quickSort(checkAgain, 0, checkAgain.size() - 1);

	// Check each line from the checkAgain vector again
	for (int i = 0; i < checkAgain.size(); i++) {
		
		// Stores data for each individual course
		string courseId;
		string courseTitle;
		vector<string> prerequisites(0);
		bool validPrereqs = true; // Tracks whether prequisites are valid

		// Check the tree for each course's prerequisites
		for (int j = 2; j < checkAgain.at(i).size(); j++) {
			// If still not found, prerequities was not in the course list, course fails to load
			if (courseList.Search(checkAgain.at(i).at(j)) == nullptr) {
				cout << "Course " << checkAgain.at(i).at(0) << " failed to load due to missing prerequsites." << endl;
				loadFailures++;
				validPrereqs = false;
				break;
			}
			// Otherwise, add prerequisite to the course's list
			else {
				prerequisites.push_back(checkAgain.at(i).at(j));
			}
		}
		// If all prerequisites for a course are found, course is valid; create the Course object and store in tree
		if (validPrereqs == true) {
			courseId = checkAgain[i][0];
			courseTitle = checkAgain[i][1];

			Course* course = new Course(courseId, courseTitle, prerequisites);
			courseList.Insert(course);
			loadSuccesses++;
		}
	}

	// Output results of the upload to screen
	cout << loadSuccesses << " courses loaded successfully." << endl;
	cout << loadFailures << " courses failed to load." << endl;
}

// Display program header
void displayTitle() {
	cout << "-----------------------------------------------------" << endl;
	cout << "|                  ABC University                   | " << endl;
	cout << "|        Academic Advising Assistance Program       |" << endl;
	cout << "|                                                   |" << endl;
	cout << "|                   Go Alphabots!                   |" << endl;
	cout << "----------------------------------------------------|" << endl << endl;
}


// MAIN() FUNCTION //
int main()
{
	const int QUIT = 9;			 // Option to QUIT is 9
	int menuSelection;           // Stores user's selection
	BinarySearchTree courseList; // Tree used to store the courses
	string filename;             // Stores name of input file

	// Set exception mask for cin stream
	cin.exceptions(ios::failbit);

	// Display program header
	displayTitle();

	do {
		try {
			// Clear out previous input
			menuSelection = 0; 

			Course* query;   // Pointer for locating a course
			string lookupId; // Stores course ID for searches 

			// Display main menu
			cout << endl;
			cout << "MAIN MENU" << endl;
			cout << "-------------------" << endl;
			cout << " 1. Load Course List" << endl;
			cout << " 2. Print Course List" << endl;
			cout << " 3. Print Course" << endl;
			cout << " 9. Exit" << endl;
			cout << endl;

			// Get user input
			cout << "Selection: ";
			cin >> menuSelection;
			cout << endl;

			// Branch to user's choice
			switch (menuSelection) {
			case 1: // LOAD COURSE LIST
				cout << "Please type name of file to load: ";
				cin >> filename;
				loadCourses(filename, courseList);
				break;
			case 2: // PRINT COURSE LIST
				courseList.PrintCourseList();
				break;
			case 3: // PRINT COURSE
				cout << "What course would you like to view: ";
				cin >> lookupId;
				for (int i = 0; i < lookupId.length(); i++) { // Convert user's input to all caps
					lookupId[i] = toupper(lookupId[i]);
				}
				cout << endl;
				query = courseList.Search(lookupId); // If course not found inform user
				if (query == nullptr) {
					cout << "Course " << lookupId << " not found." << endl;
				}
				else {                               // Otherwise print course's infor to screen
					query->PrintCourse();
					query->PrintPrerequsites();
				}
				break;
			case 9: // EXIT
				cout << "Thank you for using the ABCU course planner!" << endl << endl << endl;
				
				// Terminate program
				return 0;
			default: // INVALID SELECTION
				cout << "Invalid selection, please try again." << endl;
				break;
			}
		}
		catch (const ios_base::failure& excpt) { // Handles malfunctions due to incompatible inputs

			// Inform user of error
			cout << "Invalid selection, please enter the number of your selection." << endl;

			// Reset the status flags and clear out the cin stream
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');

			continue;
		}
	}
	while (menuSelection != QUIT);
}



