/* UserDatabase class
*   author: Chris Sharrock
*   version: 1.0
*   date last modified: 12/12/23
*
*  This class extends SQLiteOpenHelper and allows the app to create and manage a SQLite database
*  for the purposes of adding/deleting/updating users and querying the database to check for
*  username availability and validate credentials.  Two tables are used in the database, one to
*  store user profiles and the other to store weights submitted by the users.
 */

package com.snhu.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

// Interface between the WeightTracker app and the "Users" SQLite database. The Singleton Pattern
// is used to ensure only one instance of the database manager can exist at a time.
public class UserDatabase extends SQLiteOpenHelper {

    // Create an object to store the current instance of the database
    private static UserDatabase userDB;

    // Define constants for the "Users" table in the database
    private static final String DATABASE_NAME = "User Database";
    private static final int DATABASE_VERSION = 1;
    private static final String USER_TABLE_NAME = "Users";
    private static final String COUNTER = "Counter" ;
    private static final String USERNAME_FIELD = "username";
    private static final String PASSWORD_FIELD = "password";
    private static final String GOAL_FIELD = "goal";
    private static final String NEW_ACCT_FIELD = "new";
    private static final String PERMISSION_FIELD = "permissions";


    // Define constants for the "Weights" table in the database
    private static final String WEIGHT_TABLE_NAME = "History";
    private static final String ID_FIELD = "id";
    private static final String WEIGHT_FIELD = "wght";
    private static final String DATE_FIELD = "date";
    private static final String DELETED_FIELD = "deleted";
    private static final DateFormat dateFormat = new SimpleDateFormat("MM--dd--yyyy");

    // CONSTRUCTOR
    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Returns the existing instance of the database manager or creates one if it doesn't exist
    public static UserDatabase getInstance(Context context) {

        // If an instance doesn't exist, create one
        if (userDB == null) {
            userDB = new UserDatabase(context);
        }

        // Otherwise return existing instance
        return userDB;
    }

    // Executes when the database manager is created
    // Generates a table "Users" for storing user login information
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the "Users" table and define its headers
        StringBuilder sql1 = new StringBuilder()
                .append("CREATE TABLE ")
                .append(USER_TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(USERNAME_FIELD)
                .append(" TEXT, ")
                .append(PASSWORD_FIELD)
                .append(" TEXT, ")
                .append(GOAL_FIELD)
                .append(" TEXT, ")
                .append(NEW_ACCT_FIELD)
                .append(" TEXT, ")
                .append(PERMISSION_FIELD)
                .append(" TEXT)");
        db.execSQL(sql1.toString());

        // Create the "Weights" table and define its headers
        StringBuilder sql2 = new StringBuilder()
                .append("CREATE TABLE ")
                .append(WEIGHT_TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" INT, ")
                .append(USERNAME_FIELD)
                .append(" TEXT, ")
                .append(WEIGHT_FIELD)
                .append(" TEXT, ")
                .append(DATE_FIELD)
                .append(" TEXT, ")
                .append(DELETED_FIELD)
                .append(" TEXT)");
        db.execSQL(sql2.toString());
    }

    // onUpgrade() function required for child classes of SQLiteOpenHelper but it is not implemented
    // in this application
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    // Adds a new user to the database if username does not already exist
    public void addUser(String username, String password) {

        // If username exists, exit without adding a new user
        if (this.checkForUsername(username)) {
            return;
        }
        // Otherwise add the new user to the database
        else {
            // Connect to the database
            SQLiteDatabase sqlDB = this.getWritableDatabase();

            // Load the entry values for the new user
            ContentValues contentValues = new ContentValues();
            contentValues.put(USERNAME_FIELD, username);
            contentValues.put(PASSWORD_FIELD, password);
            contentValues.put(GOAL_FIELD, 0);
            contentValues.put(NEW_ACCT_FIELD, "yes");
            contentValues.put(PERMISSION_FIELD, "no");

            // Create a new user in the table
            sqlDB.insert(USER_TABLE_NAME, null, contentValues);
        }
    }

    // Update a users profile with the provided information
    // Takes username, the field to be updated (as a column number), and the new value
    public void updateUser(String username, int columnNum, String newVal) {

        // Connect to the database
        SQLiteDatabase sqlDB = this.getWritableDatabase();

        // Query for this use's profile
        Cursor result = sqlDB.rawQuery("SELECT * FROM " + USER_TABLE_NAME + " WHERE " +
                USERNAME_FIELD + "='" + username + "';", null);

        // Move to next line in result (prevents an out of index error)
        result.moveToNext();
        ContentValues contentValues = new ContentValues();

        // Update the specified field in contentValues
        switch (columnNum) {
            case 3:
                contentValues.put(GOAL_FIELD, newVal);
                break;
            case 4:
                contentValues.put(NEW_ACCT_FIELD, newVal);
                break;
            case 5:
                contentValues.put(PERMISSION_FIELD, newVal);
                break;
            default:
                break;
        }

        // Update the database with the new value
        sqlDB.update(USER_TABLE_NAME, contentValues, USERNAME_FIELD + "='" + username +"';",null);
    }

    // Adds a new weight to the "Weights" table in the database
    // Takes a Weight object as a parameter which contain all needed info
    public void addWeight(Weight weight) {
        // Connect to the database
        SQLiteDatabase sqlDB = this.getWritableDatabase();

        // Load the entry values for the new weight
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, weight.getId());
        contentValues.put(USERNAME_FIELD, weight.getUsername());
        contentValues.put(WEIGHT_FIELD, weight.getWeight());
        contentValues.put(DATE_FIELD, weight.getDate());
        contentValues.put(DELETED_FIELD, "no");

        // Create a new weight entry in the table
        sqlDB.insert(WEIGHT_TABLE_NAME, null, contentValues);
    }

    // Updates an existing weight entry in the database
    // Takes a Weight object whose new attributes are used to replace the old entry in the database
    public void updateWeight(Weight weight) {
        // Connect to the database
        SQLiteDatabase sqlDB = this.getWritableDatabase();

        // Load the updated values for the existing weight
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, weight.getId());
        contentValues.put(USERNAME_FIELD, weight.getUsername());
        contentValues.put(WEIGHT_FIELD, weight.getWeight());
        contentValues.put(DATE_FIELD, weight.getDate());
        contentValues.put(DELETED_FIELD, "no");

        // Update the weight entry in the database
        sqlDB.update(WEIGHT_TABLE_NAME, contentValues, ID_FIELD + "=" + weight.getId(),null);
    }

    // "Deletes" a weight from the database by setting its "deleted" field to "yes"
    // When the weight list is populated all weights are pulled from the database (including deleted)
    // ones but ones marked as deleted are not included in the list.
    public void deleteWeight(Weight weight) {

        // Connect to the database
        SQLiteDatabase sqlDB = this.getWritableDatabase();

        // Load the values for the weight but change deleted to "yes"
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, weight.getId());
        contentValues.put(USERNAME_FIELD, weight.getUsername());
        contentValues.put(WEIGHT_FIELD, weight.getWeight());
        contentValues.put(DATE_FIELD, weight.getDate());
        contentValues.put(DELETED_FIELD, "yes");

        // Update the database
        sqlDB.update(WEIGHT_TABLE_NAME, contentValues, ID_FIELD + "=" + weight.getId(),null);
    }

    // Queries the database and populates the weights list with the user's weights
    public void populateWeightList() {
        // Connect to the database
        SQLiteDatabase sqlDB = this.getReadableDatabase();

        try {
            // Query all weights for this user
            Cursor result = sqlDB.rawQuery("SELECT * FROM " + WEIGHT_TABLE_NAME + " WHERE " +
                    USERNAME_FIELD + "='" + MainActivity.g_username + "';", null);

            // If there is at least one result
            if (result.getCount() != 0) {
                // Loop through results and add weights to the weights list (as Weight objects)
                while (result.moveToNext()) {
                    if (result.getString(5).equals("no")) {
                        int id = result.getInt(1);
                        String username = result.getString(2);
                        String weight = result.getString(3);
                        String date = result.getString(4);
                        Weight weighIn = new Weight(id, weight, date, username);
                        Weight.weightArrayList.add(weighIn);
                    }
                }
            }
        }
        catch (NullPointerException e) {
        }
    }

    // Checks for existence of a username
    // Returns true if a username exists or false if it doesn't
    public boolean checkForUsername(String username) {

        // Connect to the database
        SQLiteDatabase sqlDB = this.getReadableDatabase();

        // Create a cursor to store the query result and query
        // for any entries with the given username
        Cursor result = sqlDB.rawQuery("SELECT * FROM " + USER_TABLE_NAME + " WHERE " +
                USERNAME_FIELD + "='" + username + "';", null);

        // If an entry with that username is in the table, the username is taken
        if (result.getCount() != 0) {
            return true;
        }
        // Otherwise the username is not taken
        return false;
    }

    // Check for first time log-in
    // Returns true if first time or false if not
    public boolean checkForFirstTimeLogin(String username) {

        // Connect to the database
        SQLiteDatabase sqlDB = this.getReadableDatabase();

        // Create a cursor to store the query result and query
        // for any entries with the given username
        Cursor result = sqlDB.rawQuery("SELECT * FROM " + USER_TABLE_NAME + " WHERE " +
                USERNAME_FIELD + "='" + username + "';", null);

        // Move cursor to next (prevents index out of order error) and check "first time" value
        result.moveToNext();
        String firstTimeLogin = result.getString(4);

        // If first time, change value to "no" and return true
        if (firstTimeLogin.equals("yes")) {
            this.updateUser(username, 4, "no");
            return true;
        }
        // Otherwise return false
        else {
            return false;
        }
    }

    // Querys user's profile and returns the value of their goal
    public String getUserGoal(String username) {

        // Connect to the database
        SQLiteDatabase sqlDB = this.getReadableDatabase();

        // Query for this user's profile
        Cursor result = sqlDB.rawQuery("SELECT * FROM " + USER_TABLE_NAME + " WHERE " +
                USERNAME_FIELD + "='" + username + "';", null);

        // Move cursor to next (prevents out of index error)
        result.moveToNext();

        // Retreive the value of this user's goal
        String userGoal = result.getString(3);

        // If goal is not 0, then user has input a goal, return the value
        if (!userGoal.equals("0")) {
            return userGoal;
        }
        // Otherwise the user has not set a goal yet; return "--" for goal field
        else {
            return "--";
        }
    }

    // Check to see if user has given permissions
    public boolean checkForPermissions(String username) {

        // Connect to the database
        SQLiteDatabase sqlDB = this.getReadableDatabase();

        // Create a cursor to store the query result and query
        // for any entries with the given username
        Cursor result = sqlDB.rawQuery("SELECT * FROM " + USER_TABLE_NAME + " WHERE " +
                USERNAME_FIELD + "='" + username + "';", null);

        // Retreive the user's permissions value from their profile
        String permissionGiven = result.getString(5);

        // If permissions given then return true
        if (permissionGiven.equals("yes")) {
            return true;
        }
        // Otherwise, return false
        else {
            return false;
        }
    }

    // Validates the provided username and password by querying the table for an entry where
    // both match; if match found, credentials are verified, return true; otherwise return false
    public boolean checkCredentials(String username, String password) {

        // Connect to database
        SQLiteDatabase sqlDB = this.getReadableDatabase();

        // Create a cursor to store the query result and query for entries with the matching
        // username and password
        Cursor result = sqlDB.rawQuery("SELECT * FROM " + USER_TABLE_NAME + " WHERE " +
                USERNAME_FIELD + "=\'" + username + "\' AND " + PASSWORD_FIELD + "=\'" +
                password + "\';", null);

        // If a matching result is found credentials are valid, return true
        if (result.getCount() >= 1) {
            return true;
        }
        // Otherwise credentials are invalid, return false
        return false;
    }
}
