/* WeightAdapter class
*   author: Chris Sharrock
*   version: 1.0
*   date last modified: 12/10/23
*
*  This class takes the weights from the list of weigh-ins and converts them into cells that can
*  be displayed as items in the Dashboard fragment's gridview. It uses the weight_cell.xml layout
*  as a template and then fills in the text fields with the date of the weigh in and the submitted
*  weight.
*/

package com.snhu.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.util.List;

public class WeightAdapter extends ArrayAdapter<Weight> {

    // Constructor which takes the context and list of weights
    public WeightAdapter(Context context, List<Weight> weights) {
        super(context, 0, weights);
    }

    // Takes the weight at the specified position and converts it into a weight cell
    @Override
    public View getView(@Nullable int position, @Nullable View convertView,
                        @Nullable ViewGroup parent) {

        // Get weight at specified position
        Weight weight = getItem(position);

        // Inflate weight_cell view for this cell
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.weight_cell, parent, false);
        }

        // Initialize the widgets for this cell
        TextView weighInDate = convertView.findViewById(R.id.cellDate);
        TextView weighInWeight = convertView.findViewById(R.id.cellWeight);

        // Fill in the cell with weigh-in date and weight
        weighInDate.setText("Date: " + weight.getDate());
        weighInWeight.setText("Weight: " + weight.getWeight());

        // Return the cell for display in the list
        return convertView;
    }
}
