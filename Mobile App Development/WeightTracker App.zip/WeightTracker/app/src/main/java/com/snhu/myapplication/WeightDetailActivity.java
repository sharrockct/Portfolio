/* WeightDetailActivity class
*   author: Chris Sharrock
*   version: 1.0
*   date last modified: 12/11/23
*
*  This class is the controller for the "WeightDetailActivity" which is created when a user selects
*  an item from the weight list gridview on the Dashboard fragment. This activity allows the user to
*  add, update, or delete a weight from the list.
*/

package com.snhu.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

// Activity for adding, updating, or deleting a weight item in the weights list
public class WeightDetailActivity extends AppCompatActivity {

    // Used to convert Date objects into a formatted date string
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("MM-dd-yyyy");

    private EditText newWeight;
    private TextView weighInDate;
    private Weight selectedWeight;
    private String currDate;

    // Calculates the current date and gets the weight value from user input
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_detail);

        // Get current date convert to formatted string
        currDate = getStringFromDate(new Date(System.currentTimeMillis()));

        // Initialize widgets
        newWeight = findViewById(R.id.weight_text);
        weighInDate = findViewById(R.id.date_text);

        // Display the current date in the date textbox
        weighInDate.setText(currDate);
    }

    // Specifies behavior when an existing weight is selected to be edited
    private void checkForEditIntent() {
        Intent currentIntent = getIntent();
        int selectedWeightID = currentIntent.getIntExtra(Weight.WEIGHT_EDIT_EXTRA, -1);
        selectedWeight = Weight.getWeightForID(selectedWeightID);

        if (selectedWeight != null) {
            newWeight.setText(selectedWeight.getWeight());
        }
    }

    // Saves a newly added or updated weight to the database
    public void saveWeight(View view) {
        // Connect to database
        UserDatabase userDB = UserDatabase.getInstance(this);

        // Get value of weight to be saved
        String weight = String.valueOf(newWeight.getText());

        // Check to see if this weight is to be edited
        checkForEditIntent();

        // If no weight exists yet, create a new one and add it to the database
        if (selectedWeight == null) {
            int id = Weight.weightArrayList.size();
            Weight newWeight = new Weight(id, weight, currDate, MainActivity.g_username);
            Weight.weightArrayList.add(newWeight);
            userDB.addWeight(newWeight);
        }
        // Otherwise if a weight does exist, query the database and update it with the new weight
        else {
            selectedWeight.setWeight(weight);
            userDB.updateWeight(selectedWeight);
        }
        // Terminate this activity (returns to Dashboard)
        finish();
    }

    // Marks this weight as "deleted" so it will no longer show in the weights list
    public void deleteWeight(View view) {

        // Check to see if this weight is to be edited
        checkForEditIntent();

        // If the selected item is not null, mark is as "deleted" in the database
        if (selectedWeight != null) {
            UserDatabase userDB = UserDatabase.getInstance(this);
            userDB.deleteWeight(selectedWeight);
            Weight.weightArrayList.remove(selectedWeight);

            // Terminate this activity (returns to Dashboard)
            finish();
        }
    }

    // Converts a Date into a formatted string
    private String getStringFromDate(Date date) {
        // If date is null, return null
        if (date == null) {
            return null;
        }
        // Otherwise, return the formatted string
        return DATE_FORMAT.format(date);
    }
}