/* Login class
*   author: Chris Sharrock
*   version: 1.0
*   date last modified: 12/13/23
*
*  This class acts as the controller for fragment_login.xml. It defines the behavior for the
*  username and password fields, the new user button, the login button, and all labels on the
*  Login screen. It accepts a username and password from a user and then allows them to either
*  add a new user or verify credentials via a "Users" SQLite database. The user will see an
*  error message on the screen if they try to create a new account with an existing username
*  or try to login with invalid credentials.
 */

package com.snhu.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

// Controller for fragment_login.xml
// Allows user to create a new account or login with an existing one
public class Login extends Fragment {

    // Declare widgets
    private UserDatabase userDatabase;
    private EditText usernameText, passwordText;
    private Button newUserButton, loginButton;
    private TextView usernameTaken, invalidCredentials, accountCreationSuccessful, fieldsBlank;

    // Executes when fragment is created, instantiates the widget objects and inflates the view
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View parentView = inflater.inflate(R.layout.fragment_login, container, false);

        initializeWidgets(parentView);

        // Return the inflated view
        return parentView;
    }

    // Initializes the widgets for this fragment and assigns callback functions
    private void initializeWidgets(View view) {
        // Get current instance of the database manager
        userDatabase = new UserDatabase(getContext());

        // Initialize widgets
        usernameText = view.findViewById(R.id.et_usernameField);
        passwordText = view.findViewById(R.id.et_passwordField);
        newUserButton = view.findViewById(R.id.b_newAccount);
        loginButton = view.findViewById(R.id.b_login);

        // Feedback messages for the user
        usernameTaken = view.findViewById(R.id.tv_username_taken);
        invalidCredentials = view.findViewById(R.id.tv_incorrect_username_or_password);
        accountCreationSuccessful = view.findViewById(R.id.tv_account_created);
        fieldsBlank = view.findViewById(R.id.tv_fields_blank);

        // Set callback functions for the buttons
        newUserButton.setOnClickListener(this::onNewUserButtonClick); // executes when "New User" is clicked
        loginButton.setOnClickListener(this::onLoginButtonClick); // executes when "Login" is clicked
    }

    // Callback function for the "New User" button
    // Checks availability of username and then creates a new user account
    private void onNewUserButtonClick(View view) {

        // Get username and password and convert to strings
        String username = usernameText.getText().toString();
        String password = passwordText.getText().toString();

        // If either username or password is blank show error message
        if (username.equals("") || password.equals("")) {
            usernameTaken.setVisibility(view.GONE);
            accountCreationSuccessful.setVisibility(view.GONE);
            invalidCredentials.setVisibility(view.GONE);
            fieldsBlank.setVisibility(View.VISIBLE);
        }
        // Otherwise check for username availability
        else if (userDatabase.checkForUsername(username)) {

            // If not available, clear any other messages and show "username taken" message
            invalidCredentials.setVisibility(view.GONE);
            accountCreationSuccessful.setVisibility(view.GONE);
            usernameTaken.setVisibility(view.VISIBLE);
            fieldsBlank.setVisibility(View.GONE);

            // Clear username and password blanks
            usernameText.setText("");
            passwordText.setText("");
        }
        // If username is available, add a new user to the database
        else {
            // Add a new user to the database using user input
            userDatabase.addUser(username, password);

            // Clear any shown messages and display "account created" message
            invalidCredentials.setVisibility(view.GONE);
            usernameTaken.setVisibility(view.GONE);
            accountCreationSuccessful.setVisibility(view.VISIBLE);
            fieldsBlank.setVisibility(View.GONE);

            // Clear username and password blanks
            usernameText.setText("");
            passwordText.setText("");
        }
    }

    // Callback function for "Login" button
    // Verifies credentials provided by the user against the "Users" database then navigates to
    // the Dashboard fragment
    private void onLoginButtonClick(View view) {

        // Get user input from the username and password fields
        String username = usernameText.getText().toString();
        String password = passwordText.getText().toString();

        // Check credentials, if valid navigate to dashboard fragment
        if (userDatabase.checkCredentials(username, password)) {
            MainActivity.g_username = username;

            Navigation.findNavController(view).navigate(R.id.action_login);
        }
        // If credentials are not valid, show error message and stay on login fragment
        else {
            // Clear any shown messages and display "invalid username/password" message
            usernameTaken.setVisibility(view.GONE);
            accountCreationSuccessful.setVisibility(view.GONE);
            invalidCredentials.setVisibility(view.VISIBLE);
            fieldsBlank.setVisibility(View.GONE);

            // Clear username and password blanks
            usernameText.setText("");
            passwordText.setText("");
        }
    }
}