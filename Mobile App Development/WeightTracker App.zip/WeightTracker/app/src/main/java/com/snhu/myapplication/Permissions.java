/* Permissions class
*   author: Chris Sharrock
*   version: 1.0
*   date last modified: 12/10/23
*
*  This class is the controller for fragment_permissions.xml and it provides a screen which prompts
*  the user for permission to send SMS notifications and allows them to select yes or no and updates
*  the user database accordingly.
*
*  Note: this class is currently not implemented within the app as android provides it's own
*  mechanism for requesting and setting permissions.
*/

package com.snhu.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

// Controller for the Permissions fragment which asks the user for permission to send SMS notifications
public class Permissions extends Fragment {

    private UserDatabase userDatabase;
    private Button yesButton, noButton;

    // Intializes the widgets for this screen and assigns callback functions
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View parentView = inflater.inflate(R.layout.fragment_permissions, container, false);

        userDatabase = new UserDatabase(getContext());

        yesButton = parentView.findViewById(R.id.b_permissionsYes);
        yesButton.setOnClickListener(this::onYesButtonClick);
        noButton = parentView.findViewById(R.id.b_permissionsNo);
        noButton.setOnClickListener(this::onNoButtonClick);

        // Return this view
        return parentView;
    }

    // Callback function for the "Yes" button
    // Updates the user's profile to show SMS permissions were granted
    private void onYesButtonClick(View view) {
        userDatabase.updateUser(MainActivity.g_username, 5, "yes");
        Navigation.findNavController(view).navigate(R.id.action_continue_to_dashboard);
    }

    // Callback function for the "No" button
    // Updates the user's profile to show SMS permissions were denied
    private void onNoButtonClick(View view) {
        userDatabase.updateUser(MainActivity.g_username, 5, "no");
        Navigation.findNavController(view).navigate(R.id.action_continue_to_dashboard);
    }
}