/* Dashboard class
*    author: Chris Sharrock
 *   version: 1.0
 *   date last modified: 12/10/23
 *
 *  This class acts as the controller for fragment_dashboard.xml. It controls the widgets on the
 *  user dashboard which displays their goal and weigh-in history and allows them to add new
 *  weights to the list, or click on existing weights to update them or remove them.
 */

package com.snhu.myapplication;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.PackageManagerCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Dashboard extends Fragment {

    private static final String CHANNEL_ID = "sms_channel";
    private GridView weightListView;
    private boolean shouldRefresh = false;
    private Button setGoalButton, logoutButton, weighInButton;
    private TextView goalBlank, blankfieldError, goalDisplay;

    // Executes when fragment is created, instantiates the widget objects and inflates the view
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View parentView = inflater.inflate(R.layout.fragment_dashboard, container, false);

        // Initalize widgets
        initializeWidgets(parentView);

        // Get the list of weights from database
        loadWeightHistory();

        //
        setWeightAdapter();
        setOnClickListener();

        // If SMS permissions haven't been granted, request them
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this.getContext(), Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this.getActivity(), new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        // Inflate the layout for this fragment
        return parentView;
    }

    // Initializes the widgets for this fragment and assigns callback functions
    private void initializeWidgets(View view) {
        // Initialize widgets
        logoutButton = view.findViewById(R.id.b_logout);
        weighInButton = view.findViewById(R.id.b_weighIn);
        setGoalButton = view.findViewById(R.id.b_set_goal);
        goalBlank = view.findViewById(R.id.et_set_goal_field);
        goalDisplay = view.findViewById(R.id.tv_goal);

        // Feedback message for user
        blankfieldError = view.findViewById(R.id.tv_goal_cant_be_blank);

        // View where weights are listed
        weightListView = view.findViewById(R.id.gv_weightHistory);

        // Assign callback functions
        logoutButton.setOnClickListener(this::onLogoutButtonClick);
        weighInButton.setOnClickListener(this::onWeighInButtonClick);
        setGoalButton.setOnClickListener(this::onSetGoalButtonClick);
    }

    // Resumes the fragment after it has been paused
    // Refreshes the fragment view, reloads the weigh history list, and checks to see if goal has
    // been reached. If goal has been met, sends a congratulatory SMS (if permissions are granted)
    @Override
    public void onResume() {
        super.onResume();

        // Refreshes view after the fragment has been paused
        if (shouldRefresh) {
            getParentFragmentManager().beginTransaction().detach(this).commit();
            getParentFragmentManager().beginTransaction().attach(this).commit();

            // Check to see if goal has been reached and if so send congratulations message
            try {
                if (!Weight.weightArrayList.isEmpty()) {
                    int lastWeightIndex = Weight.weightArrayList.size() - 1;
                    int goal = Integer.parseInt(goalDisplay.getText().toString());
                    int latestWeight = Integer.parseInt(Weight.weightArrayList.get(lastWeightIndex).getWeight());

                    if (latestWeight <= goal) {
                        sendGoalReachedSMS();
                    }
                }
            }
            // Catches errors due to non-digits in the goal field
            catch (NumberFormatException e) {
            }
        }
    }

    // Executes when fragment is paused
    // Sets the "shouldRefresh" boolean to true so the fragment knows to refresh the view when
    // resumed
    @Override
    public void onPause() {
        super.onPause();
        shouldRefresh = true;
    }

    // Executes when fragment is destroyed
    // Sets the "shouldRefresh" boolean to false so the fragment loads normally when recreated
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        shouldRefresh = false;
    }

    // Loads weigh-in history from the user database
    private void loadWeightHistory() {
        // Clear out weight list for a fresh reload
        Weight.weightArrayList.clear();

        // Connect to database and query weights for this user
        UserDatabase userDB = UserDatabase.getInstance(this.getContext());
        userDB.populateWeightList();

        // Queries the database for this user's goal and displays it to screen
        String userGoal = userDB.getUserGoal(MainActivity.g_username);
        goalDisplay.setText(userGoal);
    }

    // Sets the weight adapter to convert weights into cells for display in the gridview
    private void setWeightAdapter() {
        WeightAdapter weightAdapter = new WeightAdapter(getContext().getApplicationContext(), Weight.weightArrayList);
        weightListView.setAdapter(weightAdapter);
    }

    // Sets the onClickListener for when the user selects a weight from the list
    // Switches to the WeightDetailActivity where a weight can be updated or deleted
    private void setOnClickListener() {
        weightListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Weight selectedWeight = (Weight) weightListView.getItemAtPosition(position);
                Intent editWeightIntent = new Intent(view.getContext().getApplicationContext(), WeightDetailActivity.class);
                editWeightIntent.putExtra(Weight.WEIGHT_EDIT_EXTRA, selectedWeight.getId());
                startActivity(editWeightIntent);
            }
        });
    }

    // Callback function for the "Set Goal" button
    // Updates the user database with new goal and displays in the goal window
    private void onSetGoalButtonClick(View view) {
        // Get user input from goal blank
        String goal = goalBlank.getText().toString();

        // Display error if goal blank is empty
        if (goal.equals("")) {
            blankfieldError.setVisibility(View.VISIBLE);
            goalBlank.setText("");
        }
        // Otherwise update goal
        else {
            // Display goal to screen
            goalDisplay.setText(goal);

            // Update user's profile with new goal
            UserDatabase userDB = UserDatabase.getInstance(this.getContext());
            userDB.updateUser(MainActivity.g_username, 3, goal);
        }
    }

    // Start WeightDetailActivity to add a new weight
    public void newWeight(View view) {
        Intent newWeightIntent = new Intent(this.getActivity(), WeightDetailActivity.class);
        startActivity(newWeightIntent);
    }

    // Callback function for the "Weigh-In" button
    private void onWeighInButtonClick(View view) {
        newWeight(view);
    }

    // Callback function for the "Logout" button
    // Returns to the Login fragment
    private void onLogoutButtonClick(View view) {
        Navigation.findNavController(view).navigate(R.id.action_logout);
    }

    // Creates a notification channel for SMS notifications
    private void createNotificationChannel() {
        if ((Build.VERSION.SDK_INT) >= (Build.VERSION_CODES.S)) {
            CharSequence name = "SMS Notification Channel";
            String description = "Channel for sending SMS notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getContext().getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    // Sends an SMS message to the user
    private void sendGoalReachedSMS() {
        createNotificationChannel();

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this.getActivity(), CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notifications)
                .setContentTitle("Congratulations!")
                .setContentText("You hit your goal, nice work!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        // Specify the intent and pending intent
        Intent intent = new Intent(this.getContext().getApplicationContext(), Notifications.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("data", "value passed here");
        PendingIntent pendingIntent = PendingIntent.getActivity(getActivity().getApplicationContext(),
                0, intent, PendingIntent.FLAG_IMMUTABLE);

        // Assign the intent to the builder
        builder.setContentIntent(pendingIntent);

        // Create a notification manager
        NotificationManager notificationManager =
                (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);

        // Assign the notification to the channel
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            NotificationChannel notificationChannel = notificationManager.getNotificationChannel(CHANNEL_ID);
            if (notificationChannel == null) {
                int importance = NotificationManager.IMPORTANCE_DEFAULT;
                notificationChannel = new NotificationChannel(CHANNEL_ID, "Goal Reached", importance);
                notificationManager = getContext().getSystemService(NotificationManager.class);
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }

        // Send the message
        notificationManager.notify(0, builder.build());
    }
}