/* MainActivity class
*   author: Chris Sharrock
*   version: 1.0
*   date last modified: 12/10/23
*
*  This class is the controller for the MainActivity in the WeightTracker app. It provides a
*  fragment container for showing the different screens and controls navigation within the app
*  using a NavController
 */

package com.snhu.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import android.os.Bundle;

// MainActivity for the WeightTracker app, it controls the current view and navigation through
// a fragment container and a NavController
public class MainActivity extends AppCompatActivity {

    // Global variable for current user's username
    public static String g_username;

    // Executes when the app is started
    // Creates a NavHost and NavController to navigate between fragments
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Define the layout for the activity
        setContentView(R.layout.activity_main);

        // Create a navHost for switching between fragments
        NavHostFragment navHost = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);

        // Verify that navHost is not null and then create the NavContoller
        if (navHost != null) {
            NavController navCon = navHost.getNavController();
        }
    }
}