/* Notifications class
*   author: Chris Sharrock
*   version: 1.0
*   date last modified: 12/13/23
*
*  This class provides an simple activity for the SMS notifications for the app.
*/

package com.snhu.myapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Notifications extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
