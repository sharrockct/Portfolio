/* Weight class
*   author: Chris Sharrock
*   version: 1.0
*   date last modified: 12/13/23
*
*  This class allows for creation of Weight objects which store the details of a user's weigh in
*  for storage and retrieval within the app.
*/

package com.snhu.myapplication;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

// Creates a Weight object to store the details of a weigh-in
public class Weight {

    // This public array list serves as a list of Weight objects accessible outside the class
    public static ArrayList<Weight> weightArrayList = new ArrayList<>();
    public static String WEIGHT_EDIT_EXTRA = "setWeight";
    private String weight, dateAdded, username;
    private int id;

    // Constructor, takes username, weight, current date, and id number as parameters
    public Weight(int nextId, String newWeight, String date, String username) {
        this.id = nextId;
        this.weight = newWeight;
        this.dateAdded = date;
        this.username = username;
    }

    // Searches the weight list for the Weight with the specified ID
    public static Weight getWeightForID(int searchId) {
        for (Weight w : Weight.weightArrayList) {
            if (w.getId() == searchId) {
                return w;
            }
        }
        return null;
    }

    // Sets the value of the weight attribute to the parameter value
    public void setWeight(String newWeight) {
        this.weight = newWeight;
    }

    // Returns this Weight's ID as an int
    public int getId() {
        return this.id;
    }

    // Returns this Weight's weight as a string
    public String getWeight() {
        return this.weight;
    }

    // Returns this Weight's weigh-in date as a string
    public String getDate() {
        return this.dateAdded;
    }

    // Returns the username associated with this weight
    public String getUsername() {
        return this.username;
    }
}
