# CS-340: Project 1 
#  author: Chris Sharrock (codebase provided by SNHU)
#  date last modified: 09/30/23
#  version: 1.0
#
# This module serves as a CRUD (Create, Read, Update, Delete) interface for use
# between a Python application and MongoDB databases. It provides functions for
# each of the CRUD functionalities allowing for more efficient and 
# user-friendly database interactions.

# Import files needeed for Python/MongoB interface
from pymongo import MongoClient # Provides MongoClient for database connections

# AnimalShelter class
# ---------------------
# This class acts as an interface between an animal shelter's computer system
# and their database. Upon initialization it connects to the specified database
# and then allows for CRUD interactions with the database.
class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    # Initializes the object with info needed to connect to the database
    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # Connection Variables:
        # USER = 'aacuser'  # username for the Mongo database
        USER = username
        # PASS = 'letMeIn!' # password for the Mongo database
        PASS = password
        HOST = 'nv-desktop-services.apporto.com' # host address for mongo shell
        PORT = 31577      # port number for this user
        DB = 'AAC'        # database name
        COL  = 'animals'  # collection name
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        

    # CREATE FUNCTIONALITY
    # ---------------------
    # This function can be used to create a new document and insert it into the
    # database for later use. 
    #
    # Parameters:
    #    * self - the current instance of the AnimalShelter class (provided by 
    #             default when calling the function)
    #    * data - the information to be stored in the new document; should be a
    #             dictionary of key/value pairs; provided by user when function
    #             is called
    #
    def create(self, data):
        
        # First check that the data parameter is not empty
        if data != {}:
            
            # Insert a new document into database using the insertOne() mongo 
            # command
            # If successful, return True
            self.database.animals.insert_one(data)
            return True
        
        # If the data parameter is empty, there is nothing to insert
        else:
            # Return False
            return False

    # READ FUNCTIONALITY
    # -------------------
    # This function queries the database according to the provided search
    # criteria and returns the matching documents as a list.
    #
    # Parameters:
    #    * self - the current instance of the AnimalShelter class (provided by 
    #             default when calling the function)
    #    * data - the key/value pairs to be used to query the database; should 
    #             be a dictionary of key/value pairs; provided by user when the
    #             function is called
    #
    def read(self, data):
        
        # Query the database using the find() mongo command; store the matching
        # documents in the results list
        results = list(self.database.animals.find(data))
        
        # Return the list of results (or an empty list if there are none)
        return results 
        
    # UPDATE FUNCTIONALITY
    # ---------------------
    # This function locates one document or all documents matching
    # the search criteria (according to user selection) and updates the given
    # fields with user provided values. Returns the number of documents 
    # updated.
    #
    # Parameters:
    #    * self - the current instance of the AnimalShelter class (provided by 
    #             default when calling the function)
    #    * batchUpdate - boolean value which determines whether to update one 
    #             matching document (if False) or all of them (if True); user 
    #             provided when function is called
    #    * searchInfo - the key/value pairs for querying the documents to be
    #             updated; should be a dicitonary of key/value pairs; provided
    #             by the user when the function is called
    #    * data - the keys and new values to be updated in the document; should
    #             be a dictionay of key/value pairs; provided by the user when
    #             the function is called
    #
    def update(self, batchUpdate, searchInfo, data):
        
        counter = 0 # tracks number of documents to update
        
        # If batchUpdate is True, all docs matching the search criteria will be
        # updated
        if batchUpdate:
            
            # Update all docs matching the query using the updateMany() command
            counter = self.database.animals.update_many(searchInfo, data).modified_count
        
        # If batchUpdate is False, only the first doc matching the search 
        # criteria will be updated
        else: 
            
            # Update the first doc matching the query using the updateOne() 
            # command and save the number of documents deleted in counter 
            # variable
            counter = self.database.animals.update_one(searchInfo, data).modified_count
        
        # Return the number of documents updated
        return counter
        
    # DELETE FUNCTIONALITY      
    # ---------------------
    # This function locates one or more documents according to the specified
    # search criteria and deletes them from the database. Returns the number of
    # documents deleted.
    #
    # Parameters:
    #    * self - the current instance of the AnimalShelter class (provided by 
    #             default when calling the function)
    #    * batchDelete - boolean value which determines whether to delete one 
    #             matching document (if False) or all of them (if True); user 
    #             provided when function is called
    #    * data - the key/value pairs to be used for querying the database for
    #             the document to be deleted; should be a dictionary of 
    #             key/value pairs; provided by user when function is called
    #
    def delete(self, batchDelete, data):
        
        counter = 0 # tracks number of documents to update
        
        # If batchDelete is True, all docs matching the search criteria will be
        # deleted
        if batchDelete:
            
            # Delete all docs matching the query using the updateMany() command
            # and save the number of documents deleted in counter variable
            counter = self.database.animals.delete_many(data).deleted_count
            
        # If batchDelete is False, only the first doc matching the search 
        # criteria will be deleted
        else: 
            
            # Delete the first doc matching the query using the updateOne() 
            # command
            counter = self.database.animals.delete_one(data).deleted_count 
        
        # Return the number of documents updated
        return counter